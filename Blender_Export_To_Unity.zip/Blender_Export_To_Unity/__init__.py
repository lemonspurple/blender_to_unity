bl_info = {
    "name": "Unity FBX Exporter",
    "blender": (3, 0, 0),
    "version": (1, 5),
    "category": "Import-Export",
    "author": "LMPL",
    "description": "Exports models as FBX with optional textures (+.JSON)"
}

import bpy
import os
import json
import math
import shutil

class ExportFbxJsonOperator(bpy.types.Operator):
    bl_idname = "export.fbx_json_all_textures"
    bl_label = "Export FBX + JSON"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        export_dir = bpy.path.abspath(scene.export_directory)
        base_name = scene.export_filename.strip()
        selected_only = scene.export_selected_only
        export_textures = scene.export_textures
        ignore_transform = scene.ignore_transform

        if not export_dir.strip() or export_dir == "//":
            blend_path = bpy.data.filepath
            if blend_path:
                export_dir = os.path.dirname(bpy.path.abspath(blend_path))
                scene.export_directory = export_dir

        if base_name == "":
            if selected_only and context.active_object:
                base_name = context.active_object.name
            else:
                blend_name = os.path.splitext(os.path.basename(bpy.data.filepath))[0]
                base_name = blend_name or "Scene"

        fbx_path = os.path.join(export_dir, base_name + ".fbx")
        json_path = os.path.join(export_dir, base_name + ".json")
        os.makedirs(export_dir, exist_ok=True)

        bpy.ops.export_scene.fbx(
            filepath=fbx_path,
            use_selection=selected_only,
            axis_forward='-Z',
            axis_up='Y',
            path_mode='COPY',
            embed_textures=True
        )

        export_data = {
            "settings": {
                "export_textures": export_textures,
                "ignore_transform": ignore_transform
            },
            "objects": []
        }

        objects = [context.active_object] if selected_only else scene.objects
        for obj in objects:
            if not obj or obj.type != 'MESH':
                continue

            obj_data = {
                "name": obj.name,
                "location": list(obj.location),
                "rotation": [0, 0, 0] if ignore_transform else [math.degrees(a) for a in obj.rotation_euler],
                "scale": [1, 1, 1] if ignore_transform else list(obj.scale),
                "materials": []
            }

            for slot in obj.material_slots:
                mat = slot.material
                if not mat or not mat.use_nodes:
                    continue

                mat_info = {"name": mat.name}
                if export_textures:
                    mat_info["textures"] = {}
                    texture_types = {
                        "base_color": "Base Color",
                        "metallic": "Metallic",
                        "roughness": "Roughness",
                        "normal": "Normal",
                        "emission": "Emission",
                        "alpha": "Alpha",
                        "displacement": "Displacement",
                        "ambient_occlusion": "Ambient Occlusion"
                    }

                    for key, socket_name in texture_types.items():
                        tex_node = find_connected_image(mat, socket_name)
                        if tex_node and tex_node.image:
                            tex_name = export_image(tex_node.image, export_dir, self)
                            if tex_name:
                                mat_info["textures"][key] = tex_name

                    additional = []
                    for node in mat.node_tree.nodes:
                        if node.type == 'TEX_IMAGE' and node.image:
                            image_name = export_image(node.image, export_dir, self)
                            if image_name and image_name not in mat_info["textures"].values():
                                additional.append({
                                    "name": image_name,
                                    "node_name": node.name
                                })
                    if additional:
                        mat_info["textures"]["additional"] = additional
                else:
                    mat_info["textures"] = {}

                obj_data["materials"].append(mat_info)
            export_data["objects"].append(obj_data)

        try:
            with open(json_path, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=4)
        except:
            return {'CANCELLED'}

        self.report({'INFO'}, f"Export finished:\n{fbx_path}\n{json_path}")
        return {'FINISHED'}

def find_connected_image(material, socket_name):
    if not material or not material.use_nodes:
        return None
    for node in material.node_tree.nodes:
        if node.type == 'BSDF_PRINCIPLED':
            input_socket = node.inputs.get(socket_name)
            if input_socket and input_socket.is_linked:
                from_node = input_socket.links[0].from_node
                if from_node.type == 'TEX_IMAGE':
                    return from_node
                elif from_node.type in ['SEPRGB', 'MIX_RGB', 'NORMAL_MAP']:
                    for sock in from_node.inputs:
                        if sock.is_linked and sock.links[0].from_node.type == 'TEX_IMAGE':
                            return sock.links[0].from_node
    return None

def export_image(image, export_dir, operator):
    if not image:
        return None
    if image.packed_file:
        try:
            image.unpack(method='WRITE_LOCAL')
        except:
            pass
    src = bpy.path.abspath(image.filepath) if image.filepath else ""
    name = os.path.basename(src) if src else ""
    if not name or "." not in name:
        ext = ".png"
        safe_name = "".join([c if c not in '<>:"/\\|?* ' else "_" for c in image.name])
        name = safe_name + ext
    dst = os.path.join(export_dir, name)
    if not os.path.exists(dst):
        try:
            if src and os.path.isfile(src) and not image.is_dirty:
                shutil.copy(src, dst)
            else:
                image.save(filepath=dst, save_copy=True)
        except:
            return None
    return name

class ExportFbxJsonPanel(bpy.types.Panel):
    bl_idname = "VIEW3D_PT_fbx_json_all_textures"
    bl_label = "𝔽𝔹𝕏 𝔼𝕩𝕡𝕠𝕣𝕥𝕖𝕣𝕠𝕟𝕚"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Export FBX + Texture"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        layout.prop(scene, "export_directory")
        layout.prop(scene, "export_filename")
        layout.prop(scene, "export_selected_only")
        layout.prop(scene, "export_textures")
        layout.prop(scene, "ignore_transform")
        layout.separator()
        layout.operator("export.fbx_json_all_textures", text="Export")

def register():
    bpy.types.Scene.export_directory = bpy.props.StringProperty(
        name="Path",
        subtype='DIR_PATH',
        default="//"
    )
    bpy.types.Scene.export_filename = bpy.props.StringProperty(
        name="Name", default=""
    )
    bpy.types.Scene.export_selected_only = bpy.props.BoolProperty(
        name="📌 Only export selected", default=False
    )
    bpy.types.Scene.export_textures = bpy.props.BoolProperty(
        name="🖼️ Export textures", default=True
    )
    bpy.types.Scene.ignore_transform = bpy.props.BoolProperty(
        name="📏 Ignore scale and rotation", default=False
    )
    bpy.utils.register_class(ExportFbxJsonOperator)
    bpy.utils.register_class(ExportFbxJsonPanel)

def unregister():
    bpy.utils.unregister_class(ExportFbxJsonPanel)
    bpy.utils.unregister_class(ExportFbxJsonOperator)
    del bpy.types.Scene.export_directory
    del bpy.types.Scene.export_filename
    del bpy.types.Scene.export_selected_only
    del bpy.types.Scene.export_textures
    del bpy.types.Scene.ignore_transform

if __name__ == "__main__":
    register()
